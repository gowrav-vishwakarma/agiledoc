$(function(){

	$('.mandatory').append('<span class="mandatory-star">*</span>');

});